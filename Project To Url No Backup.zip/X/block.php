<?php
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Akses Ditolak</title>
  <style>
    body {
      background: #111;
      color: #eee;
      font-family: sans-serif;
      text-align: center;
      padding-top: 100px;
    }
    h1 {
      color: #ff5e5e;
    }
  </style>
</head>
<body>
  <h1>🚫 Akses Ditolak</h1>
  <p>Maaf, kamu tidak diizinkan mengakses folder ini secara langsung.</p>
</body>
</html>
